<div  class="trapezoid-grid">
    <!-- كرر حسب الحاجة -->
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>

    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>

    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>

    <div class="trapezoid"></div>
    <div class="trapezoid"></div>

    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>
    <div class="trapezoid"></div>


</div>
